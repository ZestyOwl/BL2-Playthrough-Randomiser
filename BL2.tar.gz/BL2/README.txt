The BL2 Playthrough Randomiser - By ZCO

Installing:
1) Download the BL2 <Archive>
2) Extract the contents of the <Archive> and put the entire BL2 folder into your root directory. 

Using the BL2 Playthrough Randomiser:

There are two modes for the randomiser: BL2 (Normal), or BL2JTTW (Completely Random)
Both can be run by double clicking the file to run in terminal, or by running the script in terminal.
After the terminal screen is finished with, a copy of your playthrough will appear in your home directory, not in your documents. 
It will be called Loadout_<Date and Time>.txt


For BL2, you will get a selection of choices for ways to randomise your playthrough. 
Adding a dose of insanity will make the game significantly harder in sometimes annoying ways.

BL2JTTW will take the element of choice away from you entirely, randomising in a playthrough that could be incredibly simple, or almost impossibly difficult.  


